/* Libraries */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <iterator>
#include <signal.h>
#include <time.h>
#include <vector>
#include <sys/syscall.h>

/* Meijer framework */
#include "framework/multiCommClass.h"
#include "framework/runnableClass.h"
#include "framework/superThread.h"
#include "framework/icoCommClass.h"

// pi-definition
#define PI 3.1459

/* SIGNAL CATCHER */
volatile bool exitbool = false;
void exit_handler(int s)
{
    printf("Caught signal %d\n", s);
    exitbool = true;
}

/* ReadConvert */
void ReadConvert(const double* src, double *dst)
{
    static double encoderCount = 16383;
    static double initialCount0 = 0;
    static double initialCount1 = 0;
    static double countPerRev0 = 5000;
    static double countPerRev1 = 2000;
    static double lastKnownGoodValue0 = 0;
	static double lastKnownGoodValue1 = 0;

	/* Scaling + Filtering (upper motor) */
	if ( ( (src[0] >= 0) || (src[0] <= encoderCount) ) )
	{
        // Negative turn
        if ( src[0] > ((encoderCount/2) + 1) )
        {
            dst[0] = ( initialCount0 - (encoderCount - abs(src[0] - lastKnownGoodValue0)) ) * (2 * (double)PI / countPerRev0); // in rad
            lastKnownGoodValue0 = ( initialCount0 - (encoderCount - abs(src[0] - lastKnownGoodValue0)) );                      // in counts
            initialCount0 = initialCount0 + lastKnownGoodValue0; // in counts
        }
        // Positive turn
        else if ( src[0] <= ((encoderCount/2) + 1) )
        {
            dst[0] = ( initialCount0 + (encoderCount - abs(src[0] - lastKnownGoodValue0)) ) * (2 * (double)PI / countPerRev0); // in rad
            lastKnownGoodValue0 = ( initialCount0 + (encoderCount - abs(src[0] - lastKnownGoodValue0)) );                      // in counts
            initialCount0 = initialCount0 + lastKnownGoodValue0; // in counts
        }
	}
	else
	{
		dst[0] = initialCount0 * (2 * (double)PI / countPerRev0); // in rad
	}

	/* Scaling + Filtering (lower motor) */
	if ( ( (src[1] >= 0) || (src[1] <= encoderCount) ) )
	{
        // Negative turn
        if ( src[1] > ((encoderCount/2) + 1) )
        {
            dst[1] = ( initialCount1 - (encoderCount - abs(src[1] - lastKnownGoodValue1)) ) * (2 * (double)PI / countPerRev1); // in rad
            lastKnownGoodValue1 = ( initialCount1 - (encoderCount - abs(src[1] - lastKnownGoodValue1)) );                      // in counts
            initialCount1 = initialCount1 + lastKnownGoodValue1; // in counts
        }
        // Positive turn
        else if ( src[1] <= ((encoderCount/2) + 1) )
        {
            dst[1] = ( initialCount1 + (encoderCount - abs(src[1] - lastKnownGoodValue1)) ) * (2 * (double)PI / countPerRev1); // in rad
            lastKnownGoodValue1 = ( initialCount1 + (encoderCount - abs(src[1] - lastKnownGoodValue1)) );                      // in counts
            initialCount1 = initialCount1 + lastKnownGoodValue1; // in counts
        }
	}
	else
	{
		dst[1] = initialCount1 * (2 * (double)PI / countPerRev1); // in rad
	}	

	// Print values
    printf("Reading value for encoder 1.\nOriginal value: %lf\nConverted value: %lf\n\n", src[0], dst[0]);
    printf("Reading value for encoder 2.\nOriginal value: %lf\nConverted value: %lf\n\n", src[1], dst[1]);
}

/* WriteConvert */
void WriteConvert(const double* src, double *dst)
{
    static double motorRange = 2047; // In number scale
    static double motorVolt = 12;    // In volt
    static double testVolt = 2;      // In volt; input known voltaga value (like 2V) and measure it with the oscilloscope
	static double lastKnownGoodValue = 0;

	/* Scaling + Filtering (both motors) */
	if ( ( (src[0] >= -motorRange) || (src[0] <= motorRange) ) )
	{
		dst[0] = (testVolt/motorVolt) * motorRange;             // Motor 1 of 12 V, scaled to [-2047, 2047]
		dst[1] = (testVolt/motorVolt) * motorRange;             // Motor 2 of 12 V, scaled to [-2047, 2047]
		lastKnownGoodValue = (testVolt/motorVolt) * motorRange; // Motors  of 12 V, scaled to [-2047, 2047]
	}
	else
	{
		dst[0] = lastKnownGoodValue;
		dst[1] = lastKnownGoodValue;
	}

	// Print values
    printf("Reading value for voltage output\nOriginal value: %lf\nConverted value (motor 1): %lf\nConverted value (motor 2): %lf\n\n", src[0], dst[0], dst[1]);
}

/* MAIN FUNCTION */
int main()
{
    /* CREATE CNTRL-C HANDLER */
    signal(SIGINT, exit_handler);

    printf("Press Ctrl-C to stop program\n"); // Note: this will 
        // not kill the program; just jump out of the wait loop. Hence,
        // you can still do proper clean-up. You are free to alter the
        // way of determining when to stop (e.g., run for a fixed time).
    
	/* PARAMETERS */
	int P1_PWM = 0;
	int P2_PWM = 0;
	int P1_ENC = 0;
	int P2_ENC = 1;

	/* CREATE PARAM FOR CONTROLLER */
	int _sendParameters [] = {P1_PWM, -1, P2_PWM, -1, -1, -1, -1, -1};
	int _receiveParameters [] = {P1_ENC, -1, -1, P2_ENC, -1, -1, -1, -1, -1, -1, -1, -1};

	IcoComm *icoComm = new IcoComm(_sendParameters, _receiveParameters);

	/********************************* MEASUREMENT / ACTUATION BLOCK *********************************/

	icoComm->SetReadConvertFcn(&ReadConvert);   // Scaling + filtering of input
	icoComm->SetWriteConvertFcn(&WriteConvert); // Scaling + filtering of output

	/*************************************************************************************************/

    /* WAIT FOR CNTRL-C */
    struct timespec t;
	t.tv_sec = 1;
	t.tv_nsec = 0;
	
    while (!exitbool) {
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &t, NULL);

        // Wait for Ctrl-C to exit
    };
    printf("Ctrl-C was pressed: Stopping gracefully...\n");

	/* FINISH */
    return 0;
}