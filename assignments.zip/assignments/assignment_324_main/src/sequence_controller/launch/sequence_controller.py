from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([        
        # Sequence controller
        Node
        (
            package='sequence_controller',
            executable='sequence_controller',
            name='sequence_controller',
            remappings=[
                ('/setpoint', '/sendData'),
            ]
        ),

        # Cam2image
        Node
        (
            package='image_tools',
            executable='cam2image',
            name='cam2image',
            remappings=[
                ('/image', '/webcam_input'),
            ]
        ),

        # Showimage (webcam)
        Node
        (
            package='image_tools',
            executable='showimage',
            name='showimage',
            remappings=[
                ('/image', '/webcam_input'),
            ]
        )

    ])