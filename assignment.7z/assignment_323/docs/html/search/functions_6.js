var searchData=
[
  ['send_67',['send',['../classframeworkComm.html#a83cced9970db502b907214b2c137612f',1,'frameworkComm']]],
  ['senddouble_68',['sendDouble',['../classxenoCommunication.html#a8a51629b904be642a5524927b11bc4da',1,'xenoCommunication']]],
  ['senddoublearray_69',['sendDoubleArray',['../classxenoCommunication.html#a8c5cbf07ccd57a7f54d5242da5c48d86',1,'xenoCommunication::sendDoubleArray()'],['../classIcoConnection.html#af1f18f6eb838074ff7a1cee8f889b7b1',1,'IcoConnection::sendDoubleArray()']]],
  ['set_70',['set',['../classxenoGPIO.html#ace7cc9103de4080f40a4f31354adfed2',1,'xenoGPIO']]],
  ['setaffinity_71',['setAffinity',['../classxenoThread.html#a249d18068c2d5b0646a40331cc81e325',1,'xenoThread']]],
  ['setreadconvertfcn_72',['setReadConvertFcn',['../classframeworkComm.html#a337964bd41e84b6fd03401668bc57c74',1,'frameworkComm']]],
  ['setsize_73',['setSize',['../classwrapper.html#a613b3ba427763a4804af780fa4a4e30d',1,'wrapper']]],
  ['setverbose_74',['setVerbose',['../classxenoCommunication.html#a27dfa793dec805b93e09315c8eb5e73b',1,'xenoCommunication::setVerbose()'],['../classframeworkComm.html#ae362dc7e0ad4f972af36148b8df8950a',1,'frameworkComm::setVerbose()']]],
  ['setwriteconvertfcn_75',['setWriteConvertFcn',['../classframeworkComm.html#ab9fd2c01711273aaa7b0c5df5125126e',1,'frameworkComm']]],
  ['start_76',['start',['../classxenoThread.html#ad6a165de022d5921b350cfc0ac4f0b65',1,'xenoThread']]],
  ['step_77',['step',['../classwrapper.html#a357c5e2a25f7ce258c9cdc8bb05c1339',1,'wrapper']]],
  ['stopthread_78',['stopThread',['../classxenoThread.html#a9d78c488d34e15f5e0f3eaae7126f513',1,'xenoThread']]]
];
