/* Libraries */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <iterator>
#include <signal.h>
#include <time.h>
#include <vector>
#include <sys/syscall.h>

/* Meijer framework */
#include "framework/multiCommClass.h"
#include "framework/runnableClass.h"
#include "framework/superThread.h"
#include "framework/icoCommClass.h"

// #include <Your 20-sim-code-generated h-file?> Don't forget to compile the cpp file by adding it to CMakeLists.txt [DONE]
#include "Controller/Controller.h" // 20-sim submodel class include file 

// pi-definition
#define PI 3.1459

/* SIGNAL CATCHER */
volatile bool exitbool = false;
void exit_handler(int s)
{
    printf("Caught signal %d\n", s);
    exitbool = true;
}

/* MAIN FUNCTION */
int main()
{
    /* CREATE CNTRL-C HANDLER */
    signal(SIGINT, exit_handler);

    printf("Press Ctrl-C to stop program\n"); // Note: this will 
        // not kill the program; just jump out of the wait loop. Hence,
        // you can still do proper clean-up. You are free to alter the
        // way of determining when to stop (e.g., run for a fixed time).
    
	/* PARAMETERS */
	int P1_PWM = 0;
	int P2_PWM = 0;
	int P1_ENC = 0;
	int P2_ENC = 1;

	/* CREATE PARAM FOR CONTROLLER */
	int _sendParameters [] = {P1_PWM, -1, P2_PWM, -1, -1, -1, -1, -1};
	int _receiveParameters [] = {P1_ENC, -1, -1, P2_ENC, -1, -1, -1, -1, -1, -1, -1, -1};

	IcoComm *icoComm = new IcoComm(_sendParameters, _receiveParameters);

	/********************************* CONTROLLER BLOCK (1) *********************************/ 

	IDDPComm *iddpcom_u = new IDDPComm(_sendParameters);
	frameworkComm *controller_uPorts[] = {
		iddpcom_u,
		icoComm};

	IDDPComm *iddpcom_y = new IDDPComm(_receiveParameters);
	frameworkComm *controller_yPorts[] = {
		iddpcom_y,
		icoComm};

	/* CREATE WRAPPER FOR CONTROLLER */
	Controller *controller_class = new Controller;
	runnable *controller_runnable = new wrapper<Controller>(
		controller_class, controller_uPorts, controller_yPorts, 2, 1); // Two inputs (setpoint, encoder), one output (control signal)

	/* INITIALIZE XENOTHREAD FOR CONTROLLER */
	xenoThread *controllerClass = new xenoThread;
	xenoThread controllerClass(controller_runnable);
	controllerClass->init(1000000, 98, 0); // Frequency of 1 kHz = 1 ms = 1000000 ns; Priority of 98 out 120; Affinity of 0

	/* LOGGING OF VALUES */
	controllerClass->enableLogging(true, 26); // Log timings to port 26 (check if the thread is indeed alive)

	/* START THREADS */
	controllerClass->start("controller");

	/****************************************************************************************/

    /* WAIT FOR CNTRL-C */
    struct timespec t;
	t.tv_sec = 0;
	t.tv_nsec = 100000000; // 1/10 second
	
    while (!exitbool) {
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &t, NULL);

        // Wait for Ctrl-C to exit
    };
    printf("Ctrl-C was pressed: Stopping gracefully...\n");

	/********************************* CONTROLLER BLOCK (2) *********************************/

    /* CLEANUP HERE */
	controllerClass->stopThread();
	controller_runnable->~xenoThread();
	controller_runnable->~runnable();

	/****************************************************************************************/

	/* FINISH */
    return 0;
}