var searchData=
[
  ['init_58',['init',['../classxenoThread.html#a19f2b2a712e280398f2e9b1c7415e20a',1,'xenoThread::init(int _ns_period, int _priority, int _affinity)'],['../classxenoThread.html#ac54ddeefcd5976658747c2857673168c',1,'xenoThread::init(int _ns_period, int _priority)']]],
  ['initsocket_59',['initSocket',['../classxenoCommunication.html#a45c882637172e985e4193087b893f440',1,'xenoCommunication']]]
];
